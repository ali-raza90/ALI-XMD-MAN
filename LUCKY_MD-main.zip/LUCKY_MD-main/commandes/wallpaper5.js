'use strict';

Object.defineProperty(exports, "__esModule", {
  'value': true
});
const {
  zokou
} = require("../framework/zokou");
zokou({
  'nomCom': "wallpaper5",
  'reaction': '🎞',
  'nomFichier': __filename
}, async (_0x389951, _0x318469, _0x46cc89) => {
  console.log("Commande saisie !!!s");
  await _0x318469.sendMessage(_0x389951, {
    'image': {
      'url': "https://telegra.ph/file/62c71795586237398b130.jpg"
    },
    'caption': "🚗𝗥𝗮𝗻𝗱𝗼𝗺 𝘄𝗮𝗹𝗹𝗽𝗮𝗽𝗲𝗿 \n\n 🚗Download it and set it to your wallpaper MADE BY ALI-XMD"
  });
});
console.log("mon test");
