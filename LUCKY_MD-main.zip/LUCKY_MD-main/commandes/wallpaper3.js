'use strict';

Object.defineProperty(exports, "__esModule", {
  'value': true
});
const {
  zokou
} = require("../framework/zokou");
zokou({
  'nomCom': "wallpaper3",
  'reaction': '🎞',
  'nomFichier': __filename
}, async (_0x496e80, _0xb3c22b, _0x21a12d) => {
  console.log("Commande saisie !!!s");
  await _0xb3c22b.sendMessage(_0x496e80, {
    'image': {
      'url': "https://telegra.ph/file/97d3d23af7aff33934aea.jpg"
    },
    'caption': "🚗𝗥𝗮𝗻𝗱𝗼𝗺 𝘄𝗮𝗹𝗹𝗽𝗮𝗽𝗲𝗿 \n\n 🚗Download it and set it to your wallpaper MADE BY ALI-XMD"
  });
});
console.log("mon test");
