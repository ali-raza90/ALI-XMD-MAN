'use strict';

Object.defineProperty(exports, "__esModule", {
  'value': true
});
const {
  zokou
} = require("../framework/zokou");
zokou({
  'nomCom': "wagroup",
  'reaction': '🤨',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x3258e7, _0x4c4732, _0x13b70c) => {
  console.log("Commande saisie !!!s");
  await _0x4c4732.sendMessage(_0x3258e7, {
    'text': "Hello 👋\n\nClick on the button below to join the OFFICIAL *ALI-XMD* WhatsApp Channel",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': "https://whatsapp.com/channel/0029VaoRxGmJpe8lgCqT1T2h",
        'mediaType': 0x1,
        'mediaUrl': "https://cdn.ironman.my.id/q/BXTKN.jpg",
        'title': "Join Our WhatsApp Group",
        'body': "Click to join the official LUCKY-MD WhatsApp group!"
      }
    }
  });
  console.log("Command executed: wagroup");
});
zokou({
  'nomCom': 'wachannel',
  'reaction': '🪀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the button below to Follow the OFFICIAL *ALI-XMD* WhatsApp Channel",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://whatsapp.com/channel/0029VaihcQv84Om8LP59fO3f',
        'mediaType': 0x1,
        'mediaUrl': "https://cdn.ironman.my.id/q/BXTKN.jpg",
        'title': "Join Our WhatsApp Channel",
        'body': "Click to join the official ALI-XMD WhatsApp channel!"
      }
    }
  });
  console.log("Command executed: wachannel");
});
zokou({
  'nomCom': 'waowner',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the button below to contact the OFFICIAL *ALI-XMD* Owner",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https:// wa.me/923003588997',
        'mediaType': 0x1,
        'mediaUrl': "https://cdn.ironman.my.id/q/BXTKN.jpg",
        'title': "Join Our Developer Place",
        'body': "Click to join the official ALI-XMD Owner Inbox!"
      }
    }
  });
  console.log("Command executed: waowner");
});
zokou({
  'nomCom': 'fb-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *ALI* Facebook Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.facebook.com/profile.php?id=61553209932337',
        'mediaType': 0x1,
        'mediaUrl': "https://cdn.ironman.my.id/q/BXTKN.jpg",
        'title': "Follow Facebook Page 📄",
        'body': "Click to join the official ALI Facebook Page!"
      }
    }
  });
  console.log("Command executed: fb-page");
});
zokou({
  'nomCom': 'insta-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *ALI* Instagram Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.instagram.com/fredi.simba.tz',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/7irwqn.jpeg",
        'title': "Follow Instagram Page 📄",
        'body': "Click to join the official FREDIETECH Instagram Page!"
      }
    }
  });
  console.log("Command executed: insta-page");
});
zokou({
  'nomCom': 'threads-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *FREDIETECH* Threads Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.threads.net/@fredi.simba.tz',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/7irwqn.jpeg",
        'title': "Follow Threads Page 📄",
        'body': "Click to join the official FREDIETECH Threads Page!"
      }
    }
  });
  console.log("Command executed: threads-page");
});
zokou({
  'nomCom': 'tiktok-page',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Follow the OFFICIAL *FREDIETECH* TikTok Page",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.tiktok.com/@fredietech',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/7irwqn.jpeg",
        'title': "Follow TikTok Page 📄",
        'body': "Click to join the official FREDIETECH TikTok Page!"
      }
    }
  });
  console.log("Command executed: tiktok-page");
});
zokou({
  'nomCom': 'tgroup',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Join the OFFICIAL *LUCKY_MD* Telegram Group",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://t.me/+u3zlb5y6OfxhOTdk',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/7irwqn.jpeg",
        'title': "Join Telegram Group📄",
        'body': "Click to join the official LUCKY_MD Telegram Group!"
      }
    }
  });
  console.log("Command executed: tgroup");
});
zokou({
  'nomCom': 'ytchannel',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to Subscribe the OFFICIAL *FREDIETECH* YouTube Channel",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://www.youtube.com/@freeonlinetvT1',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/7irwqn.jpeg",
        'title': "Follow YouTube Channel📄",
        'body': "Click to Subscribe the official FREDIETECH YouTube Channel!"
      }
    }
  });
  console.log("Command executed: ytchannel");
});
zokou({
  'nomCom': 't-help',
  'reaction': '👀',
  'categorie': "Support-Owner",
  'nomFichier': __filename
}, async (_0x14c950, _0x346e6b, _0x31cbea) => {
  console.log("Commande saisie !!!s");
  await _0x346e6b.sendMessage(_0x14c950, {
    'text': "Hello 👋\n\nClick on the photo below to connect the OFFICIAL *FREDIETECH* Telegram Inbox",
    'contextInfo': {
      'externalAdReply': {
        'sourceUrl': 'https://t.me/freditech',
        'mediaType': 0x1,
        'mediaUrl': "https://files.catbox.moe/7irwqn.jpeg",
        'title': "Chating With Owner",
        'body': "Click to Contact the official FREDIETECH Telegram Inbox!"
      }
    }
  });
  console.log("Command executed: t-help");
});
